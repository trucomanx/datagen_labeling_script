#!/usr/bin/python

import subprocess
import sys

def my_install(package):
    subprocess.check_call([sys.executable, "-m", "pip3", "install", package])
    
import os
from natsort import os_sorted



def func_list_dataset_and_save(dirpath=".",formats=['.jpeg','.JPEG','.jpg','.JPG','.png','.PNG','.bmp','.BMP']):
    '''
    Crea en dirpath un archivo "statistics.cv" y "dataset.json" con 
    las estadisticas de los archivos de tipo `formats` en el directorio `dirpath`.
    El programa solo analiza los subdirectorios de primer nivel en dirpath.
    Los datos deben estar ordenados en directorios.
    
    :param dirpath: Path a analizar.
    :type dirpath: string
    :param formats: Lista de formatos de archivo que seran buscados.
    :type formats: list[string]
    :return: Retorna un diccionario con el contenido del archivo "dataset.json".
    :rtype: dic(string,string)
    ''' 
    print("Working on:",dirpath)
    if(os.path.isdir(dirpath)==False):
        print("Directory",dirpath,"no exist!");
        return 0;
    lista=[x[0] for x in os.walk(dirpath)]
    #[print(x) for x in lista]
    
    directory=[]
    for data in lista:
        if((data!=dirpath)and(os.path.isdir(data))):
            directory.append(data);

    #[print(x) for x in directory]

    Total=0;
    string='';
    dictraw={};
    for data in directory:
        lista0=[x[2] for x in os.walk(data)][0];
        lista=[];
        for x in lista0:
            filename, ext = os.path.splitext(x);
            if(ext in formats):
                lista.append(x);
        
        lista=os_sorted(lista);
        
        data_rel= os.path.relpath(data, dirpath);
        dictraw[data_rel]=lista;
        Total=Total+len(lista);
        print(data_rel,"\t",len(lista))
        string=string+data_rel+','+str(len(lista))+'\n';
    
    string=string+"Total"+','+str(Total)+'\n';
    print("Total:",Total);

    text_file = open(os.path.join(dirpath,"statistics.csv"), "w")
    text_file.write("%s" % string)
    text_file.close()

    import json
    with open(os.path.join(dirpath,'dataset.json'), 'w') as f:
        json.dump(dictraw, f, indent=4)
    return dictraw;

import sys

def main():
    my_install("natsort")
    if(len(sys.argv)==1):
        dictraw=func_list_dataset_and_save(dirpath=".");
    else:
        print("sys.argv:",sys.argv)
        dictraw=func_list_dataset_and_save(dirpath=sys.argv[1]);
    
    return 0

if __name__ == '__main__':
    sys.exit(main())  # next section explains the use of sys.exit
