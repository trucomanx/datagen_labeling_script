#!/usr/bin/python

import sys
import os

sys.path.append('/home/fernando/Proyectos/PÓS-GRADUAÇÂO/TESIS-DOUTORADO-2/PESQUISA/libraries/WorkingWithFiles/src');
import WorkingWithFiles as rnfunc

sys.path.append('/home/fernando/Proyectos/PÓS-GRADUAÇÂO/TESIS-DOUTORADO-2/PESQUISA/libraries/OpenPifPafTools/src');
import OpenPifPafTools.OpenPifPafAnnotations as opp

sys.path.append('/home/fernando/Proyectos/PÓS-GRADUAÇÂO/TESIS-DOUTORADO-2/PESQUISA/libraries/NumpyToJson/src');
import NumpyToJson as n2j


basedir='/mnt/boveda/DATASETs/PATIENT-IMAGES';

negative_list=[ os.path.join(basedir,"dataset_800/anger"),
                os.path.join(basedir,"dataset_800/disgust"),
                os.path.join(basedir,"dataset_800/fear"),
                os.path.join(basedir,"dataset_800/pain"),
                os.path.join(basedir,"dataset_800/sad"),
                os.path.join(basedir,"dataset_800/surprise-disgust")];
neutral_list=[os.path.join(basedir,"dataset_800/neutro")]
positive_list=[ os.path.join(basedir,"dataset_800/happy"),
                os.path.join(basedir,"dataset_800/surprise-happy")];

lista1=rnfunc.get_all_files_in_dir_list(negative_list);
lista2=rnfunc.get_all_files_in_dir_list(neutral_list);
lista3=rnfunc.get_all_files_in_dir_list(positive_list);

try: 
    os.mkdir('output') 
except: 
    pass

total=lista1+lista2+lista3

k=1;
for filepath in total:
    print(filepath)
    annotation,pil_im=opp.get_openpifpaf_annotation_from_imgpath(filepath);
    if(len(annotation)>1):
        for annot in annotation:
            opp.save_openpifpaf_annotation_in_imgpath(filepath,[annot],os.path.join('output','salida'+str(k)+'.png'));
            n2j.numpy_to_json_file('annotation',annot.data,os.path.join('output','salida'+str(k)+'.json'))
            k=k+1;
